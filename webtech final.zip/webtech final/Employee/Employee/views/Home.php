<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="">
    <title>Home</title>
    <style>
        /* Additional styles for home */
        body {
            background-color: offwhite; 
            margin: 10;
            padding: 0;
            display: flex;
        }

        .home {
            display: flex;
            flex-direction: row;
            width: 100%;
            height: 100vh;
        }

        .sidebar {
            width: 200px;
            background-color:orange
; 
            color: white;
            padding: 20px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.2);
        }

        .sidebar button {
            display: block;
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            background-color: white; 
            color: black;
            font-size: 1em;
            cursor: pointer;
            text-align: center;
            
        }      
    </style>
</head>
<body>
    <div class="home">
        <div class="sidebar">
            <button onclick="location.href='profile.php'">Profile</button>
            <button onclick="location.href='changepassword.php'">Change Password</button>
			
        </div>
       
    </div>

</body>
</html>
