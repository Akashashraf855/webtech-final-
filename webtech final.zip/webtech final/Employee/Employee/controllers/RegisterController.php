<?php
// registerController.php
include('../models/User.php');

session_start();



if ($_SERVER['REQUEST_METHOD'] == 'POST') { 
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $gender = $_POST['gender'];
	
	$sql = "SELECT email FROM user WHERE email='$email'";
	$result = $conn->query($sql);
	
	$stmt = $conn->prepare("INSERT INTO users (name, email, password, gender) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $password, $gender);

if($result->num_rows > 0)
{
	echo "Email Already Exist";
}
	

    elseif ($stmt->execute()) {
         header("Location: ../views/Home.php");
    } 
	else {
        echo "Error: " . $stmt->error;
    }
	
	

    $stmt->close();
    $conn->close();
}
?>
