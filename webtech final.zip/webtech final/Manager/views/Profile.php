<?php
// profile.php
session_start();
include('../models/User.php');

//$id = $_GET['id'] ?? null;
$email = $_GET['email'] ?? null;
//$email = $_SESSION['email'];
$sql = "SELECT name, email, gender FROM users WHERE email='$email'";
$result = $conn->query($sql);
$user = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $new_name = $_POST['name'];
    //$new_contact_number = $_POST['contact_number'];

    $update_sql = "UPDATE users SET name='$new_name', WHERE email='$email'";
    if ($conn->query($update_sql) === TRUE) {
        $message = "Profile updated successfully!";
    } else {
        $message = "Error updating profile: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="">
    <title>Profile</title>
    <style>
    #example4 {
		background-color: maroon;
	    text-align: center;
		margin: auto;
		position: absolute;
		justify-content: center;
        border: 2px solid black;
        padding: 50px;
        border-radius: 25px;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);	
		
		.form-group label {
        display: block;
        margin-bottom: 5px;
        }
		
		
		
		div.absolute {
        position: absolute;
        down: 80px;
        right: 0;
        width: 100px;
        height: 100px;
}

    </style>
</head>
<body style="background-color:moccasin;">
    <div id="example4">
        <h2>Profile Information</h2>
        <?php if (isset($message)) { echo "<p>$message</p>"; } ?>
        <form method="POST">
            
            <label for="new_name">Name:</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
			<br><br>
            <label for="email">Email:</label>
            <input type="text" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            <br><br>
            <label for="gender">Gender:</label>
            <input type="text" id="gender" value="<?php echo htmlspecialchars($user['gender']); ?>" readonly>
            <br><br>
            <button type="submit" class="button">Update</button>
        </form>
       <div class="absolute">
        <a href="../controllers/logout.php" class="button">Logout</a>
		</div>
    </div>
    
</body>
</html>
