<!DOCTYPE HTML>  
<html>
<head>
<style>
.error {color: #FF0000;}
</style>
	<style>
	
	#example2 {
		background-color: maroon;
	    text-align: center;
		margin: auto;
		position: absolute;
		justify-content: center;
        border: 2px solid black;
        padding: 50px;
        border-radius: 25px;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);	
		
		.form-group label {
        display: block;
        margin-bottom: 5px;
        }
		
		
		
		div.absolute {
        position: absolute;
        down: 80px;
        right: 0;
        width: 100px;
        height: 100px;
}

	
	</style>
</head>
<script type="text/javascript" src="Home.js"> </script>
<script src="jquery-3.2.1.min.js"></script>
<script src="script.js"></script>
<body style="background-color:moccasin;">



<div id="example2" >
<h2>REGISTRATION </h2>

<form id="register" action="../controllers/registerController.php" method="POST" onsubmit="return isValidR();">  


        <label for="name">Name:</label>
        <input type="text" id="name" name="name" placeholder="Enter your name" required>
		<br><br>
        <label for="email">Email:</label>
		<span class="email_error text-danger ml-2"></span>
        <input type="email" id="email" name="email" class="email_id" placeholder="Enter your email" required>
		<br><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" placeholder="Enter your password" required>
		<br><br>
        <label for="confirm_password">Confirm Password:</label>
        <input type="password" id="confirm_password" placeholder="Confirm your password" required>
		<br><br>
        <label>Gender:</label>
        <input type="radio" id="female" name="gender" value="female">
        <label for="female">Female</label>
		<input type="radio" id="male" name="gender" value="male" required>
        <label for="male">Male</label>
        <input type="radio" id="other" name="gender" value="other">
        <label for="other">Other</label>
		<br><br>
  <input type="submit" name="submit" value="Submit">
  <div class="absolute">
  <a href="../controllers/Logout.php">Logout</a>
  </div>
</div>  
</form>

    <script>
	 $(document).ready(function() {
		 $('.email_id').keyup(funtion (e) {
			 var email = $('.email_id').val();
			 
			 $.ajax({
				 type: "POST",
				 url: "EmailExistance.php",
				 data: {
					 'check_email':1,
					 'email':email,
				 },
				 success: function (response) {
					 
				 }
			 });
			 
		 });
		 
	 });
	
	</script>

    <script>
	function isValidR(){
        document.getElementById("register").addEventListener("submit", function (e) {
            var name = document.getElementById("name").value;
            var email = document.getElementById("email").value;
            var password = document.getElementById("password").value;
            var confirmPassword = document.getElementById("confirm_password").value;
            var gender = document.querySelector('input[name="gender"]:checked');
            //var errorMsg = document.getElementById("errorMsg");

            // Validation checks
            if (name === "" || email === "" || password === "" || confirmPassword === "" || !gender) {
                e.preventDefault();
                errorMsg.textContent = "All fields are required.";
                return;
            }
			
			 if (!/\S+@\S+\.\S+/.test(email)) {
                e.preventDefault();
                errorMsg.textContent = "Invalid email format.";
                return;
            }

            if (password !== confirmPassword) {
                e.preventDefault();
                errorMsg.textContent = "Passwords do not match.";
                return;
            }

           
        });
	}
    </script>



</body>
</html>	

	