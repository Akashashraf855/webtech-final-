<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title> User List </title>
<style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px;
        }
        table {
            width: 50%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
</style>

</head>

<body>

<div class="user_1">
<h2> List Of Users</h2>
<a class="btn btn-primery" href="../views/Register.php" role="button">Add New User</a>
<br>

<table id="myTable" class="table">


<tr>
<th>Name</th>
<th>Email</th>
<th>Gender</th>
</tr>

<tbody>

<?php

session_start();

include('../models/User.php');

$sql ="SELECT * FROM users";
$result = $conn->query($sql);

if(!$result){
	die("Invalid query:" . $conn->error);
}

while($row = $result->fetch_assoc()) {
	echo
"<tr>
<td>$row[name]</td>
<td>$row[email]</td>
<td>$row[gender]</td>
<td><a href='Delete.php?id=".$row['id']."' id='btn'>Remove</a></td></tr>";
	
}

  $conn->close();
?>


</tbody>


</table>


<script>
function myFunction(){
	document.getElementById("myTable").deleteRow(0);
}
</script>

</div>
 <a href="../controllers/logout.php" class="button">Logout</a>

</body>
</html>
