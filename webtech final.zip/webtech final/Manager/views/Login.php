<?php 
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
	<style>
	#example1 {
	    text-align: center;
		background-color: maroon;
		margin: auto;
		position: absolute;
		justify-content: center;
        border: 2px solid black;
        padding: 50px;
        border-radius: 25px;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
		
		.form-group label {
        display: block;
        margin-bottom: 5px;
        }
        	
}	

div{background-color: lightblue;}
	</style>
</head>
<body style="background-color:moccasin;">

	<form id="login" method="post" action="../controllers/LoginController.php" onsubmit="return isValid();" >
	
	<div id="example1" color: skyblue>
	
		
		<label for="email">Email:</label>
        <input type="email" id="email" name="email" placeholder="Enter your email" required>
		<br><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" placeholder="Enter your password" required>
		<br><br>
        <p id="errorMsg"></p>
		<a href='../views/Register.php'>Register here</a>
		<input  type="submit" value="Login">
	</div>
	</form>
	

	
	 <script>
	 function isValid(){
        document.getElementById("login").addEventListener("submit", function (e) {
            var email = document.getElementById("email").value;
            var password = document.getElementById("password").value;
            var errorMsg = document.getElementById("errorMsg");

            // Validation checks
            if (email === "" || password === "") {
                e.preventDefault(); // Prevent form submission
                errorMsg.textContent = "Please Enter Both email and password .";
            }
        });
	 }
    </script>

</body>
</html>