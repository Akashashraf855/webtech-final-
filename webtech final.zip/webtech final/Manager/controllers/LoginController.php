<?php
// loginController.php
include('../models/User.php');

session_start(); // Start the session

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Query to check user credentials
    $sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Successful login

        header("Location: ../views/Home.php"); 
        exit();
    } else {
        
        echo "Invalid email or password." ;
		
    }

    $conn->close();
}
?>
